import PlaygroundSupport //it will let us see the live view of models
import MetalKit //to make use of metal framework

//checking the suitability of the GPU
guard let device = MTLCreateSystemDefaultDevice() else {
    fatalError("GPU is not supported")
}
guard let commandQueue = device.makeCommandQueue() else {
    fatalError("Could not create command queue")
}


/*
 The command queue and device should setup at the start of the app and should use the same queue and device throughout the app.
 */

//setting up the view for model

let frame = CGRect(x: 0, y: 0, width: 600, height: 600)
let view = MTKView(frame: frame, device: device)




view.clearColor = MTLClearColor(red: 0, green: 1, blue: 0.8, alpha: 1)

//instead of loading the 3D model, we are loading primitive; basic shape.

let allocator = MTKMeshBufferAllocator(device: device) //it manages the memory of mesh data

let modelMesh = MDLMesh(sphereWithExtent: [0.75, 0.75, 0.75], segments: [100, 100], inwardNormals: false, geometryType: .triangles, allocator: allocator) //creates the sphere with specified size and returns the model

let mesh = try MTKMesh(mesh: modelMesh, device: device) //converting from model I/O to MetalKit Mesh.

//creating the command queue

//creating the shader function which requires MSL (Metal Shader Language). Typically, the separate file is made with .metal extension.

let shader = """
#include <metal_stdlib>
using namespace metal;

struct VertexIn {
    float4 position [[ attribute(0) ]];
};

vertex float4 vertex_main(const VertexIn vertex_in[[ stage_in ]]) {
    return vertex_in.position;
}

fragment float4 fragment_main() {
    return float4(1, 0, 0, 1);
}
"""

/*
 vertex_main: this function is use for manipulating the position of model
 
 fragment_main: this function is use for the pixel color.
 */

//setting up the metal libray that contain these two functions.

let library = try device.makeLibrary(source: shader, options: nil)

let vertexFunction = library.makeFunction(name: "vertex_main")
let fragmentFunction = library.makeFunction(name: "fragment_main")

//the compiler will the check if these two functions exist and make them available for pipeline descriptor.

let descriptor = MTLRenderPipelineDescriptor()

descriptor.colorAttachments[0].pixelFormat = .bgra8Unorm
descriptor.vertexFunction = vertexFunction
descriptor.fragmentFunction = fragmentFunction
descriptor.vertexDescriptor = MTKMetalVertexDescriptorFromModelIO(mesh.vertexDescriptor) //it will convert the model I/O vertex to metal vertex

//now that, the descriptor has been created. We will create pipeline from the descriptor

let pipeline = try device.makeRenderPipelineState(descriptor: descriptor)

//now we will render the sphere using MTKView

guard let commandBuffer = commandQueue.makeCommandBuffer(), let descriptor = view.currentRenderPassDescriptor, let renderEncoder = commandBuffer.makeRenderCommandEncoder(descriptor: descriptor) else {
    fatalError()
}

/*
 commandBuffer holds the command that will run on GPU
 descriptor holds the view's render pass descriptor which holds the information about the render destination, called "attachments"
 renderEncoder holds the information, necessary to send to the GPU to draw vertices.
*/

renderEncoder.setRenderPipelineState(pipeline) //giving the renderEncoder the pipeLine state
renderEncoder.setVertexBuffer(mesh.vertexBuffers[0].buffer, offset: 0, index: 0)

//creating a submesh to render the sphere

guard let subMesh = mesh.submeshes.first else {
    fatalError()
}

//renderEncoder.setTriangleFillMode(.lines)

//now drawing the the model with DRAW CALL

renderEncoder.drawIndexedPrimitives(type: .triangle, indexCount: subMesh.indexCount, indexType: subMesh.indexType, indexBuffer: subMesh.indexBuffer.buffer, indexBufferOffset: 0)

//now we will send commands to render the sphere

renderEncoder.endEncoding()

guard let drawable = view.currentDrawable else {
    fatalError()
}

commandBuffer.present(drawable)
commandBuffer.commit()

PlaygroundPage.current.liveView = view
